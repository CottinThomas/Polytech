#ifndef _MAIN_H
#define _MAIN_H


#include <stdio.h>
#include <string.h>
#include <stdlib.h>


const int NOTE_PARTIEL = 0;
const int NOTE_CC = 1;
const int NOTE_EXAM1 = 2;
const int NOTE_EXAM2 = 3;

#endif