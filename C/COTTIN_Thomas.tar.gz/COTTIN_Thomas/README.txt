TP numéro 5 - Développement Logiciel
Travail réalisé par COTTIN Thomas, APP3


COMPILATION DU PROGRAMME
########################

Prérequis : avoir le compilateur GCC d'installé

Ce projet est fourni avec un Makefile. Il vous suffit donc de vous déplacer dans le dossier du projet et de lancer la commande 'make' depuis un terminal.
Le fichier executable COTTIN_Thomas est alors généré.


SI VOUS NE POSSEDEZ PAS GCC
###########################

Il vous faut compiler le programme manuellement, avec votre compilateur favorit.

Exemple avec le compilateur clang : 
	clang -o COTTIN_Thomas main.c main.h etudiant.c etudiant.h classe.c classe.h