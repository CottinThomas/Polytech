// Copyright © 2015 Université Paris-Sud, Written by Lénaïc Bagnères, lenaic.bagneres@u-psud.fr

// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <limits>

#include "simd.hpp"


int main()
{
	vfloat32_t floats = _mm_set_ps(4.f, 3.f, 2.f, 1.f);
	std::cout << "floats = " << floats << std::endl;
	
	// TODO
	// Compute: vfloat32_t r = { 1.f + 2.f + 3.f + 4.f, 0.f, 0.f, 0.f }
	// using _mm_shuffle_ps, _mm_add_ps, vfloat32_shuffle, vfloat32_zero from simd.hpp
	
	return 0;
}
